import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface NavbarProps {
  revealTrigger?: number;
}

type TabType = 'Discover' | 'Flavors' | 'Refresh' | 'Explore';

export const Navbar: React.FC<NavbarProps> = ({ revealTrigger = 0 }) => {
  const [activeTab, setActiveTab] = useState<TabType>('Discover');

  const navTabs: TabType[] = ['Discover', 'Flavors', 'Refresh', 'Explore'];

  const handleTabClick = (tab: TabType) => {
    setActiveTab(tab);
    spriteAudio.playButtonTap();

    if (tab === 'Flavors') {
      const el = document.getElementById('flavors');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'Refresh' || tab === 'Explore') {
      const aboutEl = document.getElementById('about');
      aboutEl?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header className="absolute top-0 left-0 right-0 z-40 px-12 pt-8 w-full flex items-center justify-between select-none pointer-events-auto">
      {/* 
        Subtle, restrained shadow layer behind the navbar creating gentle separation from the sky
      */}
      <div className="absolute inset-x-0 -top-6 h-28 bg-gradient-to-b from-black/[0.07] via-black/[0.025] to-transparent pointer-events-none -z-10 blur-sm" />

      {/* 1. Brand Logo (Left) with subtle drop shadow */}
      <motion.div
        key={`logo-${revealTrigger}`}
        initial={{ y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.1, ease: [0.19, 1, 0.22, 1] }}
        className="flex items-center"
      >
        <button
          onClick={() => {
            spriteAudio.playButtonTap();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="transition-transform hover:scale-105 active:scale-95 duration-200 cursor-pointer outline-none"
          aria-label="Sprite Home"
        >
          <SpriteLogo className="h-9 sm:h-10 drop-shadow-[0_2px_8px_rgba(0,0,0,0.18)]" />
        </button>
      </motion.div>

      {/* 2. Navigation Items (Center - Exact match to IMG-20260826-WA0014.jpg) */}
      <motion.nav
        key={`nav-${revealTrigger}`}
        initial={{ y: -25, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.2, ease: [0.19, 1, 0.22, 1] }}
        className="flex items-center gap-6 md:gap-10 font-montserrat text-[15px] drop-shadow-[0_1px_4px_rgba(0,25,50,0.12)]"
      >
        {navTabs.map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => handleTabClick(tab)}
              onMouseEnter={() => spriteAudio.playButtonHover()}
              className={`relative cursor-pointer transition-colors duration-200 outline-none flex flex-col items-center select-none ${
                isActive
                  ? 'px-7 py-2 rounded-full bg-white/20 backdrop-blur-md text-white font-medium shadow-[inset_0_1px_1px_rgba(255,255,255,0.4),0_2px_8px_rgba(0,0,0,0.06)]'
                  : 'px-2 py-2 text-white/90 hover:text-white font-normal'
              }`}
            >
              <span>{tab}</span>
              {/* Vibrant lime/green dot indicator for Refresh */}
              {tab === 'Refresh' && !isActive && (
                <span className="absolute -bottom-1 w-1.5 h-1.5 rounded-full bg-[#82D926] shadow-[0_0_6px_#82D926]" />
              )}
            </button>
          );
        })}
      </motion.nav>

      {/* 3. Shop Sprite CTA (Right - Matching reference design) */}
      <motion.div
        key={`cta-${revealTrigger}`}
        initial={{ y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, delay: 0.3, ease: [0.19, 1, 0.22, 1] }}
        className="flex items-center drop-shadow-[0_1px_4px_rgba(0,25,50,0.12)]"
      >
        <button
          onClick={() => {
            spriteAudio.playCanPop();
            const el = document.getElementById('flavors');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          className="group flex items-center gap-2 text-white/95 hover:text-white font-montserrat text-[15px] font-medium transition-transform hover:scale-105 active:scale-95 duration-200 cursor-pointer select-none outline-none"
        >
          <span>Shop Sprite</span>
          <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200 text-[#82D926]" />
        </button>
      </motion.div>
    </header>
  );
};
