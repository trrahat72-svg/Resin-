import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { Navbar } from './Navbar';
import { SocialLinks } from './SocialLinks';
import { FooterDetails } from './FooterDetails';
import { SpriteInteractiveCTA } from './SpriteInteractiveCTA';
import { BubbleAtmosphere } from './BubbleAtmosphere';
import { ProductSpotlightReveal } from './ProductSpotlightReveal';
import { SectionScrollBlur } from './SectionScrollBlur';

const BACKGROUND_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753603/1_20260826_200445_0000_u7lbnw.png';
const FOREGROUND_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753604/file_00000000689081fdba99b19e7dbc6094_hf8odj.png';
const REVEAL_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787799318/file_00000000db2882098893b24b1616b047_uw6bka.png';
const SKY_CLOUD_MASK_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787815925/file_00000000d2848211a74f06c8f2a75677_vyxyww.png';

const CANVAS_WIDTH = 1440;
const CANVAS_HEIGHT = 1080;

interface HeroCanvasProps {
  revealTrigger?: number;
}

export const HeroCanvas: React.FC<HeroCanvasProps> = () => {
  const [scale, setScale] = useState<number>(1);
  const [containerHeight, setContainerHeight] = useState<number>(1080);
  const outerWrapperRef = useRef<HTMLDivElement>(null);

  // Dynamically calculate scale factor to fit the 1440x1080 design in any desktop display seamlessly
  useEffect(() => {
    const handleResize = () => {
      if (outerWrapperRef.current) {
        const availableWidth = window.innerWidth;
        const finalScale = availableWidth / CANVAS_WIDTH;
        setScale(finalScale > 0 ? finalScale : 1);
        setContainerHeight(Math.round(CANVAS_HEIGHT * (finalScale > 0 ? finalScale : 1)));
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const headlineLetters = ['R', 'E', 'F', 'R', 'E', 'S', 'H'];

  return (
    <div
      ref={outerWrapperRef}
      id="sprite-hero-wrapper"
      className="relative w-full overflow-visible flex flex-col items-center justify-start select-none bg-[#6db2ea]"
      style={{ height: `${containerHeight}px` }}
    >
      {/* Outer ambient full-bleed background for ultrawide / large screens */}
      <div className="absolute inset-0 w-full h-full z-0 overflow-hidden pointer-events-none">
        <img
          src={BACKGROUND_IMG}
          alt=""
          className="w-full h-full object-cover object-center scale-105"
          crossOrigin="anonymous"
          loading="eager"
        />
      </div>

      {/* Scaled 1440 x 1080 Design Canvas */}
      <div
        id="sprite-hero-canvas"
        className="relative flex-shrink-0 z-20 overflow-visible"
        style={{
          width: `${CANVAS_WIDTH}px`,
          height: `${CANVAS_HEIGHT}px`,
          transform: `scale(${scale})`,
          transformOrigin: 'top center',
        }}
      >
        {/* 1. BACKGROUND SCENIC LAYER WITH INDIVIDUAL PAN-ZOOM & RADIANT LIGHT BLOOM */}
        <motion.div
          initial={{ scale: 1.08, opacity: 0.85 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.6, ease: [0.19, 1, 0.22, 1] }}
          className="absolute inset-0 w-full h-full z-0 overflow-hidden"
        >
          <img
            src={BACKGROUND_IMG}
            alt="Scenic Sprite Sky and Clouds Background"
            className="w-full h-full object-cover object-center pointer-events-none"
            crossOrigin="anonymous"
            loading="eager"
          />
          {/* Dynamic White Luminous Sunburst / Soft Lighting Bloom behind Can */}
          <motion.div
            initial={{ scale: 0.4, opacity: 0 }}
            animate={{ scale: [0.4, 1.3, 1], opacity: [0, 0.5, 0.25] }}
            transition={{ duration: 2.2, ease: [0.19, 1, 0.22, 1] }}
            className="absolute left-1/2 top-[55%] -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(255,255,255,0.45) 0%, rgba(255,248,220,0.2) 35%, rgba(255,255,255,0) 70%)',
            }}
          />
        </motion.div>

        {/* Ambient Bubbles with Fizzy Drift */}
        <BubbleAtmosphere />

        {/* 2. MAIN HEADLINE ("REFRESH") - INDIVIDUALLY ANIMATED LETTER BY LETTER */}
        {/* Canva Spec: Lilita One, W: 3146.7px, H: 399.8px, X: -828.2px, Y: 180px */}
        <div
          id="main-headline-refresh"
          className="absolute z-10 flex items-center justify-center pointer-events-none"
          style={{
            left: '-853.3px',
            top: '180px',
            width: '3146.7px',
            height: '399.8px',
          }}
        >
          <h1
            className="font-lilita flex items-center justify-center select-none"
            style={{
              fontSize: '336px',
              lineHeight: '399.8px',
              letterSpacing: '-0.042em',
            }}
          >
            {headlineLetters.map((char, index) => (
              <span
                key={`${char}-${index}`}
                className="inline-block overflow-hidden pb-4"
                style={{ perspective: '800px' }}
              >
                <motion.span
                  className="inline-block text-headline-3d"
                  initial={{
                    y: 160,
                    opacity: 0,
                    rotateX: 35,
                    filter: 'blur(8px)',
                  }}
                  animate={{
                    y: 0,
                    opacity: 1,
                    rotateX: 0,
                    filter: 'blur(0px)',
                  }}
                  transition={{
                    duration: 1.2,
                    delay: 0.15 + index * 0.05,
                    ease: [0.19, 1, 0.22, 1],
                  }}
                >
                  {char}
                </motion.span>
              </span>
            ))}
          </h1>
        </div>

        {/* 3. SUB-HEADLINE LEFT ("YOUR") - KINETIC SLIDE & PERSPECTIVE TILT */}
        {/* Canva Spec: W: 252.9px, H: 112.3px, X: 302px, Y: 518.8px */}
        <div
          id="subheadline-your"
          className="absolute z-10 flex items-center justify-center pointer-events-none"
          style={{
            left: '302px',
            top: '518.8px',
            width: '252.9px',
            height: '112.3px',
          }}
        >
          <div className="overflow-hidden p-2">
            <motion.span
              initial={{
                x: -100,
                opacity: 0,
                rotate: -6,
                filter: 'blur(8px)',
              }}
              animate={{
                x: 0,
                opacity: 1,
                rotate: 0,
                filter: 'blur(0px)',
              }}
              transition={{
                duration: 1.3,
                delay: 0.45,
                ease: [0.19, 1, 0.22, 1],
              }}
              className="inline-block font-lilita text-subheadline-3d select-none"
              style={{
                fontSize: '94px',
                lineHeight: '112.3px',
                letterSpacing: '0.02em',
              }}
            >
              YOUR
            </motion.span>
          </div>
        </div>

        {/* 4. SUB-HEADLINE RIGHT ("WORLD") - KINETIC SLIDE FROM RIGHT */}
        {/* Canva Spec: W: 332.4px, H: 102.7px, X: 858px, Y: 518.8px */}
        <div
          id="subheadline-world"
          className="absolute z-10 flex items-center justify-center pointer-events-none"
          style={{
            left: '858px',
            top: '518.8px',
            width: '332.4px',
            height: '102.7px',
          }}
        >
          <div className="overflow-hidden p-2">
            <motion.span
              initial={{
                x: 100,
                opacity: 0,
                rotate: 6,
                filter: 'blur(8px)',
              }}
              animate={{
                x: 0,
                opacity: 1,
                rotate: 0,
                filter: 'blur(0px)',
              }}
              transition={{
                duration: 1.3,
                delay: 0.55,
                ease: [0.19, 1, 0.22, 1],
              }}
              className="inline-block font-lilita text-subheadline-3d select-none"
              style={{
                fontSize: '94px',
                lineHeight: '102.7px',
                letterSpacing: '0.02em',
              }}
            >
              WORLD
            </motion.span>
          </div>
        </div>

        {/* 5. FOREGROUND HERO PRODUCT (Sprite Can on Moss Island) */}
        <div
          id="foreground-sprite-can"
          className="absolute z-30 pointer-events-auto"
          style={{
            left: '175px',
            top: '421.7px',
            width: '1099.7px',
            height: '692.0px',
          }}
        >
          <ProductSpotlightReveal
            baseImage={FOREGROUND_IMG}
            revealImage={REVEAL_IMG}
            alt="Sprite Can on Moss Island"
            spotlightRadius={220}
          />
        </div>

        {/* 5B. ATMOSPHERIC CLOUD / SKY MASK (Absolute top-most layer z-[90], shifted 40px top to bottom: -260px, 100% opacity) */}
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.99 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 1.4, delay: 0.25, ease: [0.19, 1, 0.22, 1] }}
          className="absolute pointer-events-none z-[90]"
          style={{
            left: '-205px',
            bottom: '-260px',
            width: '1850px',
            height: '760px',
            filter: 'blur(2px)',
            opacity: 1,
          }}
        >
          <img
            src={SKY_CLOUD_MASK_IMG}
            alt="Atmospheric Clouds Mask"
            className="w-full h-full object-contain object-bottom scale-125"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>

        {/* Smooth bottom edge blending gradient & progressive scroll blur into About section */}
        <SectionScrollBlur
          position="bottom"
          height={200}
          maxBlur={14}
          tintColor="rgba(109, 178, 234, 0.2)"
        />

        {/* 6. CTA BUTTON ("Explore Sprite" + "->") WITH RIPPLE BLOOM POP */}
        <motion.div
          initial={{ opacity: 0, y: 40, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{
            duration: 1.1,
            delay: 0.65,
            ease: [0.34, 1.4, 0.64, 1], // Spring pop
          }}
          id="cta-button-container"
          className="absolute z-35 flex items-center justify-center"
          style={{
            left: '592px',
            top: '848px',
            height: '56px',
          }}
        >
          <SpriteInteractiveCTA
            onExplore={() => {
              const aboutEl = document.getElementById('about');
              aboutEl?.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        </motion.div>

        {/* 7. TOP NAVIGATION BAR */}
        <Navbar />

        {/* 8. BOTTOM LEFT SOCIAL LINKS */}
        <SocialLinks />

        {/* 9. BOTTOM RIGHT FOOTER CONTENT */}
        <FooterDetails />
      </div>
    </div>
  );
};
