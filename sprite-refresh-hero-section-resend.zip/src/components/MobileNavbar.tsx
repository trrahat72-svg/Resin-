import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { SpriteLogo } from './SpriteLogo';
import { spriteAudio } from '../utils/audio';

interface MobileNavbarProps {
  revealTrigger?: number;
}

export const MobileNavbar: React.FC<MobileNavbarProps> = ({ revealTrigger = 0 }) => {
  const [activeTab, setActiveTab] = useState<'Discover' | 'Flavors' | 'Shop'>('Discover');

  const handleNavClick = (tab: 'Discover' | 'Flavors' | 'Shop') => {
    setActiveTab(tab);
    spriteAudio.playButtonTap();
    if (tab === 'Flavors') {
      const el = document.getElementById('flavors');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (tab === 'Shop') {
      const el = document.getElementById('about');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-40 px-4 pt-3.5 pb-2 flex items-center justify-between w-full pointer-events-none">
      {/* Sprite Logo with Refractive Glass Glow */}
      <motion.div
        key={`mob-logo-${revealTrigger}`}
        initial={{ y: -25, opacity: 0, scale: 0.9 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
        className="relative pointer-events-auto"
      >
        <button
          onClick={() => {
            spriteAudio.playButtonTap();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="transition-transform active:scale-95 duration-200 block cursor-pointer outline-none"
          aria-label="Sprite Home"
        >
          <SpriteLogo className="h-7 drop-shadow-[0_2px_10px_rgba(0,0,0,0.2)]" />
        </button>
      </motion.div>

      {/* Floating Liquid Glass Nav Capsule */}
      <motion.nav
        key={`mob-liquid-nav-${revealTrigger}`}
        initial={{ y: -25, opacity: 0, scale: 0.92 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.85, delay: 0.1, ease: [0.19, 1, 0.22, 1] }}
        className="pointer-events-auto flex items-center p-1 rounded-full border border-white/40 shadow-[0_10px_28px_rgba(0,0,0,0.2),inset_0_1px_1.5px_rgba(255,255,255,0.7)] backdrop-blur-2xl bg-white/20 overflow-hidden"
      >
        {(['Discover', 'Flavors', 'Shop'] as const).map((tab) => {
          const isActive = activeTab === tab;
          return (
            <button
              key={tab}
              onClick={() => handleNavClick(tab)}
              className={`relative z-10 px-3.5 py-1.5 rounded-full font-montserrat text-xs tracking-wider transition-colors duration-200 cursor-pointer outline-none ${
                isActive ? 'text-[#003816] font-bold' : 'text-white/90 font-medium'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="mobLiquidActivePill"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-[#D8FA00] via-[#E8FF3B] to-[#D8FA00] shadow-[0_2px_10px_rgba(216,250,0,0.45)]"
                />
              )}
              <span className="relative z-10">{tab}</span>
            </button>
          );
        })}
      </motion.nav>
    </header>
  );
};
