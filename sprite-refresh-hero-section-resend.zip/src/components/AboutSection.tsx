import React, { useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { ScrollBlur } from './ScrollBlur';
import { TextRevealScroll } from './TextRevealScroll';
import { Flip3DText } from './Flip3DText';
import { ParticleText } from './ParticleText';
import { SectionScrollBlur } from './SectionScrollBlur';

const ABOUT_BG_IMAGE = 'https://res.cloudinary.com/hm4hiju8/image/upload/v1787807893/629618799_1787807879317356.jpg';

export const AboutSection: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [badgeClickCount, setBadgeClickCount] = useState<number>(0);

  // Responsive scroll scrub linked strictly to normalized scroll progress
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start 90%', 'end 10%'],
  });

  // Smooth layered parallax scroll offsets
  const bgY = useTransform(scrollYProgress, [0, 1], [-50, 50]);
  const textGroupY = useTransform(scrollYProgress, [0, 1], [20, -20]);
  const stickerScrollY = useTransform(scrollYProgress, [0, 1], [15, -15]);

  // Faster, more responsive scroll highlighting transforms for the FIRE UP badge
  const badgeOpacity = useTransform(scrollYProgress, [0.2, 0.4], [0.45, 1]);
  const badgeScale = useTransform(scrollYProgress, [0.2, 0.38], [0.94, 1]);
  const badgeShadow = useTransform(
    scrollYProgress,
    [0.2, 0.4],
    [
      '0px 2px 8px rgba(0, 0, 0, 0.08)',
      '0px 14px 36px rgba(0, 0, 0, 0.22), 0px 4px 10px rgba(0, 0, 0, 0.12)',
    ]
  );

  // Depth-of-field blurred bokeh bubbles parallax scrub
  const bubbleForegroundY = useTransform(scrollYProgress, [0, 1], [90, -90]);
  const bubbleMidgroundY = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const bubbleBackgroundY = useTransform(scrollYProgress, [0, 1], [30, -30]);

  const handleBadgeClick = () => {
    setBadgeClickCount((c) => c + 1);
  };

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative z-10 w-full aspect-[9/16] md:aspect-[4/3] md:min-h-[780px] bg-[#6db2ea] text-white flex flex-col items-center justify-center select-none overflow-visible py-12 md:py-0 will-change-transform"
      style={{ transform: 'translateZ(0)' }}
    >
      {/* 
        ========================================================================
        1. ATMOSPHERIC SKY & CLOUDS BACKGROUND WITH PARALLAX BLUR
        ========================================================================
      */}
      <ScrollBlur
        scrollProgress={scrollYProgress}
        maxBlur={6}
        maxScale={1.04}
        parallaxOffset={40}
        direction="focus-center"
        className="absolute -inset-16 w-[calc(100%+128px)] h-[calc(100%+128px)] pointer-events-none z-0 overflow-hidden"
      >
        <motion.div style={{ y: bgY }} className="w-full h-full">
          <img
            src={ABOUT_BG_IMAGE}
            alt="Atmospheric Clouds and Sky"
            className="w-full h-full object-cover object-center opacity-100"
            crossOrigin="anonymous"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-sky-400/15 via-transparent to-[#559fda]/25 pointer-events-none" />
        </motion.div>
      </ScrollBlur>

      {/* 
        ========================================================================
        2. INTERACTIVE PARTICLE TEXT CANVAS (SPRITE CITRUS & BUBBLE PARTICLES)
        ========================================================================
      */}
      <div className="absolute inset-0 z-5 pointer-events-auto flex items-center justify-center opacity-40 hover:opacity-85 transition-opacity duration-500">
        <ParticleText
          text="SPRITE"
          className="w-full h-[60%] max-w-4xl"
          particleSize={2.8}
          interactive={true}
        />
      </div>

      {/* 
        Soft bottom blending gradient and progressive optical scroll blur into Flavors section below
      */}
      <SectionScrollBlur
        position="bottom"
        height={220}
        maxBlur={16}
        scrollProgress={scrollYProgress}
        tintColor="rgba(98, 185, 243, 0.25)"
      />

      {/* 
        ========================================================================
        3. BLURRED BUBBLE PARTICLES (DEPTH OF FIELD PARALLAX)
        ========================================================================
      */}
      <motion.div
        style={{ y: bubbleForegroundY }}
        className="absolute top-[8%] left-[4%] sm:left-[8%] pointer-events-none z-10"
      >
        <div
          className="w-32 h-32 sm:w-44 sm:h-44 md:w-56 md:h-56 rounded-full bg-white/20 border border-white/30 shadow-[inset_0_4px_16px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
          }}
        >
          <div className="absolute top-4 left-6 w-10 h-5 rounded-full bg-white/70 -rotate-45" />
          <div className="absolute bottom-6 right-8 w-5 h-5 rounded-full bg-white/40" />
        </div>
      </motion.div>

      <motion.div
        style={{ y: bubbleMidgroundY }}
        className="absolute top-[16%] right-[5%] sm:right-[10%] pointer-events-none z-10"
      >
        <div
          className="w-24 h-24 sm:w-36 sm:h-36 md:w-44 md:h-44 rounded-full bg-white/22 border border-white/35 shadow-[inset_0_4px_14px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(4px)',
            WebkitBackdropFilter: 'blur(4px)',
          }}
        >
          <div className="absolute top-3 left-4 w-8 h-4 rounded-full bg-white/75 -rotate-45" />
          <div className="absolute bottom-3 right-5 w-4 h-4 rounded-full bg-white/35" />
        </div>
      </motion.div>

      <motion.div
        style={{ y: bubbleBackgroundY }}
        className="absolute bottom-[14%] left-[8%] sm:left-[14%] pointer-events-none z-10"
      >
        <div
          className="w-16 h-16 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-full bg-white/25 border border-white/40 shadow-[inset_0_2px_10px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(3px)',
          }}
        >
          <div className="absolute top-2 left-3 w-5 h-2.5 rounded-full bg-white/80 -rotate-45" />
        </div>
      </motion.div>

      <motion.div
        style={{ y: bubbleForegroundY }}
        className="absolute bottom-[8%] right-[4%] sm:right-[8%] pointer-events-none z-10"
      >
        <div
          className="w-28 h-28 sm:w-40 sm:h-40 md:w-52 md:h-52 rounded-full bg-white/20 border border-white/30 shadow-[inset_0_4px_16px_rgba(255,255,255,0.6)] relative overflow-hidden"
          style={{
            filter: 'blur(7px)',
          }}
        >
          <div className="absolute top-4 left-5 w-9 h-4.5 rounded-full bg-white/70 -rotate-45" />
          <div className="absolute bottom-5 right-6 w-4 h-4 rounded-full bg-white/30" />
        </div>
      </motion.div>

      {/* 
        ========================================================================
        4. TYPOGRAPHY WITH FAST & RESPONSIVE SCROLL HIGHLIGHTING
        ========================================================================
      */}
      <motion.div
        style={{ y: textGroupY }}
        className="relative z-30 w-full max-w-5xl px-4 sm:px-6 lg:px-8 py-8 sm:py-16 md:py-0 landscape:max-md:-translate-y-[15px] flex flex-col items-center justify-center text-center tracking-normal"
      >
        {/* LINE 1: STIR UP YOUR (Highlights rapidly on scroll) */}
        <TextRevealScroll
          text="STIR UP YOUR"
          progress={scrollYProgress}
          range={[0.02, 0.20]}
          className="w-full"
          textClassName="font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.2)]"
        />

        {/* LINE 2: FEARLESS PAST AND (Fast follow-through) */}
        <TextRevealScroll
          text="FEARLESS PAST AND"
          progress={scrollYProgress}
          range={[0.14, 0.34]}
          className="w-full mt-1 sm:mt-2"
          textClassName="font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.2)]"
        />

        {/* LINE 3: ICONIC SPRITE BRAND PILL [FIRE UP] WITH 3D FLIP TEXT ANIMATION */}
        <motion.div
          style={{ y: stickerScrollY }}
          className="my-3 sm:my-5 md:my-7 z-30 inline-flex items-center justify-center"
        >
          <motion.div
            style={{
              opacity: badgeOpacity,
              scale: badgeScale,
              boxShadow: badgeShadow,
            }}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            onClick={handleBadgeClick}
            className="relative inline-flex items-center gap-2.5 sm:gap-4 md:gap-5 px-7 sm:px-12 md:px-16 py-2 sm:py-3 md:py-3.5 rounded-full bg-gradient-to-r from-[#D8FA00] via-[#E9FF47] to-[#D8FA00] text-[#003816] font-lilita text-[clamp(1.75rem,7vw,2.4rem)] sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl uppercase tracking-wide border border-white/70 select-none overflow-hidden cursor-pointer shadow-[0_8px_24px_rgba(216,250,0,0.3)] transition-transform duration-200"
          >
            {/* Ambient inner rim reflection */}
            <div className="absolute inset-0 rounded-full shadow-[inset_0_1.5px_2px_rgba(255,255,255,0.9),inset_0_-2px_4px_rgba(0,50,20,0.12)] pointer-events-none" />

            {/* Left Citrus Spark Star */}
            <motion.svg
              animate={{ rotate: badgeClickCount * 180 - 12 }}
              transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
              className="w-4 h-4 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#003816]/75 fill-current shrink-0"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path d="M12 0L14.4 9.6L24 12L14.4 14.4L12 24L9.6 14.4L0 12L9.6 9.6L12 0Z" />
            </motion.svg>

            {/* 3D Flip Text Component */}
            <Flip3DText
              text="FIRE UP"
              onClick={handleBadgeClick}
              className="transform translate-y-[2px]"
            />

            {/* Right Citrus Spark Star */}
            <motion.svg
              animate={{ rotate: badgeClickCount * -180 + 12 }}
              transition={{ duration: 0.6, ease: [0.34, 1.56, 0.64, 1] }}
              className="w-4 h-4 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#003816]/75 fill-current shrink-0"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path d="M12 0L14.4 9.6L24 12L14.4 14.4L12 24L9.6 14.4L0 12L9.6 9.6L12 0Z" />
            </motion.svg>
          </motion.div>
        </motion.div>

        {/* LINE 4: YOUR FUTURE WITH EVERY (Rapid trigger) */}
        <TextRevealScroll
          text="YOUR FUTURE WITH EVERY"
          progress={scrollYProgress}
          range={[0.30, 0.52]}
          className="w-full"
          textClassName="font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.2)]"
        />

        {/* LINE 5: GULP OF PERFECT CAFFEINE (Rapid completion) */}
        <TextRevealScroll
          text="GULP OF PERFECT CAFFEINE"
          progress={scrollYProgress}
          range={[0.44, 0.68]}
          className="w-full mt-1 sm:mt-2"
          textClassName="font-lilita text-[clamp(1.85rem,7.5vw,2.5rem)] sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl uppercase tracking-tight leading-[1.08] text-white drop-shadow-[0_4px_12px_rgba(0,0,0,0.2)]"
        />
      </motion.div>
    </section>
  );
};
