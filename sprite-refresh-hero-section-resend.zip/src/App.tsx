import React from 'react';
import { HeroCanvas } from './components/HeroCanvas';
import { MobileHero } from './components/MobileHero';
import { AboutSection } from './components/AboutSection';
import { FlavorsSection } from './components/FlavorsSection';
import { SpriteCinematicReveal } from './components/SpriteCinematicReveal';

export default function App() {
  return (
    <main className="relative w-full min-h-screen bg-[#62b9f3] text-white overflow-x-hidden select-none">
      {/* Fast In-to-Out Shutter Preloader */}
      <SpriteCinematicReveal />

      {/* 1. DESKTOP HERO VIEWPORT (md and above) */}
      <div id="home" className="hidden md:block w-full relative overflow-visible z-40 bg-[#6db2ea]">
        <HeroCanvas />
      </div>

      {/* 2. MOBILE HERO VIEWPORT */}
      <div id="mobile-home" className="block md:hidden w-full min-h-screen relative overflow-visible z-40 bg-[#6db2ea]">
        <MobileHero />
      </div>

      {/* 3. ABOUT SECTION */}
      <div className="relative z-10 w-full overflow-visible">
        <AboutSection />
      </div>

      {/* 4. FLAVORS SECTION */}
      <div className="relative z-20 w-full overflow-visible">
        <FlavorsSection />
      </div>
    </main>
  );
}
